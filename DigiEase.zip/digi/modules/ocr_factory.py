from .english_ocr import EnglishOCR
from .devanagari_ocr import DevanagariOCR
from .hindi_ocr import HindiOCR


class OCRFactory:
    def __init__(self):
        self.english_ocr = EnglishOCR()
        self.devanagari_ocr = DevanagariOCR()
        self.hindi_ocr = HindiOCR()

    def get_processor(self, language: str):
        language = language.lower()

        if language == "eng":
            return self.english_ocr
        elif language == "hin":
            return self.hindi_ocr  # use specialized HindiOCR
        elif language in ["mar", "san", "devanagari"]:
            return self.devanagari_ocr
        else:
            raise ValueError(f"Unsupported language: {language}")

        return processor.extract_text(image_path)

    # Create a singleton instance
    def process_image(self, image_path: str, language: str):
        processor = self.get_processor(language)
        return processor.extract_text(image_path)


# Create a singleton instance
ocr_factory = OCRFactory()

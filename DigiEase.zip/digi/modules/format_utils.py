from PIL import Image, ImageDraw, ImageFont
from reportlab.pdfgen import canvas
from io import BytesIO

# Standardized Font Settings
STANDARD_FONT_SIZE = 30 # Increased from 12 to 40 for better Marathi text rendering
STANDARD_FONT_PATH = "C:\\Windows\\Fonts\\Arial.ttf"  # Fallback font
MARATHI_FONT_PATH = (
    r"C:\Users\ASUS\Downloads\digi\fonts\NotoSansDevanagari.ttf"  # Marathi font
)


class FontMetrics:
    def __init__(self, font_size=STANDARD_FONT_SIZE):  # Use the new standard font size
        self.font_size = font_size
        try:
            self.font = ImageFont.truetype(MARATHI_FONT_PATH, size=font_size)
        except IOError:
            # Fall back to default font if Marathi font is not found
            try:
                self.font = ImageFont.truetype(STANDARD_FONT_PATH, size=font_size)
            except IOError:
                self.font = ImageFont.load_default()


# HTML Output
def save_as_html(spans, original_dimensions):
    width, height = original_dimensions
    html = f"<div style='position: relative; width: {width}px; height: {height}px; background: white;'>"

    for span in spans:
        text = span.get("text", "").replace(" ", "&nbsp;")  # Preserve spacing
        left = span["bbox"]["left"]
        top = span["bbox"]["top"]
        width = span["bbox"]["width"]
        height = span["bbox"]["height"]

        # Use standardized font size
        font_size = STANDARD_FONT_SIZE

        html += f"""
        <p style='position: absolute;
                  left: {left}px;
                  top: {top}px;
                  width: {width}px;
                  height: {height}px;
                  font-size: {font_size}px;
                  line-height: {font_size}px;
                  margin: 0;
                  padding: 0;
                  white-space: nowrap;
                  font-family: "Noto Sans Devanagari", Arial, sans-serif;'>
            {text}
        </p>
        """

    html += "</div>"

    full_html = f"""<html>
<head>
    <meta charset='utf-8'>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari&display=swap');
    </style>
</head>
<body>{html}</body>
</html>"""

    # Return HTML content as bytes instead of saving to file
    return full_html.encode("utf-8")


# PDF Output
def save_as_pdf(spans, original_dimensions):
    width, height = original_dimensions

    # Create PDF in memory
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=(width, height))

    # Try to use Devanagari font for PDF
    try:
        # ReportLab uses different font system - we need to register fonts
        # This is a simplified approach - in production code, you'd properly register the font
        c.setFont("Helvetica", STANDARD_FONT_SIZE)  # Fallback to Helvetica
    except:
        c.setFont("Helvetica", STANDARD_FONT_SIZE)

    for span in spans:
        text = span.get("text", "")
        left = span["bbox"]["left"]
        top = height - span["bbox"]["top"]  # Adjust Y-axis
        c.drawString(left, top, text)

    c.save()

    # Return bytes of PDF
    buffer.seek(0)
    return buffer.getvalue()


# PNG Output
def save_as_png(input_image_path, spans):
    """
    Generate PNG image with text overlay

    Parameters:
    - input_image_path: Path to the original image
    - spans: List of text spans with bounding boxes

    Returns:
    - Bytes of the generated PNG
    """
    # Handle input as path or bytes
    if isinstance(input_image_path, str):
        img = Image.open(input_image_path)
    elif isinstance(input_image_path, bytes):
        img = Image.open(BytesIO(input_image_path))
    elif isinstance(input_image_path, BytesIO):
        img = Image.open(input_image_path)
    else:
        raise ValueError("Input image must be a file path, bytes, or BytesIO")

    # Create a new white image with the same dimensions
    width, height = img.size
    blank_img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(blank_img)

    # Try to use Marathi font
    try:
        font = ImageFont.truetype(MARATHI_FONT_PATH, STANDARD_FONT_SIZE)
    except IOError:
        try:
            font = ImageFont.truetype(STANDARD_FONT_PATH, STANDARD_FONT_SIZE)
        except IOError:
            font = ImageFont.load_default()

    for span in spans:
        text = span.get("text", "")
        left = span["bbox"]["left"]
        top = span["bbox"]["top"]

        draw.text((left, top), text, fill="black", font=font)

    # Save to BytesIO instead of file
    buffer = BytesIO()
    blank_img.save(buffer, format="PNG")
    buffer.seek(0)

    return buffer.getvalue()


# Main Function
def format_text(extracted_text, input_image_path, output_format="png"):
    """
    Format extracted OCR text into different output formats

    Parameters:
    - extracted_text: List of text spans with bounding boxes or a string
    - input_image_path: Path to the original image or image bytes
    - output_format: 'html', 'pdf', or 'png'

    Returns:
    - Bytes of the formatted output
    """
    # Get original image dimensions
    if isinstance(input_image_path, str):
        with Image.open(input_image_path) as img:
            original_dimensions = img.size
    elif isinstance(input_image_path, bytes):
        with Image.open(BytesIO(input_image_path)) as img:
            original_dimensions = img.size
    elif isinstance(input_image_path, BytesIO):
        with Image.open(input_image_path) as img:
            original_dimensions = img.size
    else:
        raise ValueError("Input image must be a file path, bytes, or BytesIO")

    # Handle string input
    if isinstance(extracted_text, str):
        font_metrics = FontMetrics()
        text_width = font_metrics.font.getbbox(extracted_text)[2]
        text_height = font_metrics.font.getbbox(extracted_text)[3]

        extracted_text = [
            {
                "text": extracted_text,
                "bbox": {
                    "left": 0,
                    "top": 0,
                    "width": text_width,
                    "height": text_height,
                },
            }
        ]

    # Process based on requested output format
    if output_format == "html":
        return save_as_html(extracted_text, original_dimensions)
    elif output_format == "pdf":
        return save_as_pdf(extracted_text, original_dimensions)
    elif output_format == "png":
        return save_as_png(input_image_path, extracted_text)
    else:
        raise ValueError("Invalid format! Choose 'html', 'pdf', or 'png'.")

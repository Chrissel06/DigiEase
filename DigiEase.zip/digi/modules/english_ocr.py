# Save this as devanagari_ocr.py
import cv2
import numpy as np
import pytesseract
from PIL import Image
import os
import statistics
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import models, transforms
from torchvision.models.detection import FasterRCNN
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from torchvision.transforms import functional as F
import easyocr
from typing import Dict, List, Tuple, Union


class EnglishOCR:
    def __init__(
        self,
        tesseract_path: str = r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        use_rcnn: bool = True,
        rcnn_model_path: str = None,
    ):
        pytesseract.pytesseract.tesseract_cmd = tesseract_path
        self.config = r"--oem 3 --psm 6 -l eng"
        self.use_rcnn = use_rcnn

        if self.use_rcnn:
            self.rcnn_model = models.detection.fasterrcnn_resnet50_fpn(pretrained=True)
            if rcnn_model_path and os.path.exists(rcnn_model_path):
                self.rcnn_model.load_state_dict(torch.load(rcnn_model_path))
            self.rcnn_model.eval()

        self.reader = easyocr.Reader(["en"], gpu=torch.cuda.is_available())

    def detect_text_regions(self, image: np.ndarray) -> List[Tuple[int, int, int, int]]:
        if not self.use_rcnn:
            h, w = image.shape[:2]
            return [(0, 0, w, h)]

        image_tensor = F.to_tensor(
            Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        ).unsqueeze(0)

        with torch.no_grad():
            outputs = self.rcnn_model(image_tensor)

        boxes = outputs[0]["boxes"].cpu().numpy()
        scores = outputs[0]["scores"].cpu().numpy()

        return [
            tuple(box.astype(np.int32))
            for idx, box in enumerate(boxes)
            if scores[idx] > 0.5
        ] or [(0, 0, image.shape[1], image.shape[0])]

    def preprocess_image(self, image: np.ndarray) -> List[Tuple[str, np.ndarray]]:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        preprocessed_images = []

        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        _, binary = cv2.threshold(blurred, 150, 255, cv2.THRESH_BINARY)
        preprocessed_images.append(("binary", binary))

        _, otsu_binary = cv2.threshold(
            gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
        )
        preprocessed_images.append(("otsu_binary", otsu_binary))

        adaptive = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
        )
        preprocessed_images.append(("adaptive", adaptive))

        denoised = cv2.fastNlMeansDenoising(gray)
        preprocessed_images.append(("denoised", denoised))

        kernel = np.ones((1, 2), np.uint8)
        morph_connect = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
        preprocessed_images.append(("morph_connect", morph_connect))

        edge_enhanced = cv2.add(gray, cv2.Laplacian(gray, cv2.CV_8U))
        _, edge_bin = cv2.threshold(
            edge_enhanced, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
        )
        preprocessed_images.append(("edge_enhanced", edge_bin))

        return preprocessed_images

    def extract_text_from_regions(
        self, image: np.ndarray, boxes: List[Tuple[int, int, int, int]]
    ) -> List[Dict]:
        results = []
        height, width = image.shape[:2]

        for x1, y1, x2, y2 in boxes:
            x1, y1, x2, y2 = map(
                int, [max(0, x1), max(0, y1), min(width, x2), min(height, y2)]
            )
            if x2 <= x1 or y2 <= y1:
                continue

            roi = image[y1:y2, x1:x2]
            if roi.size == 0:
                continue

            ocr_results = self.reader.readtext(roi)
            for bbox, text, conf in ocr_results:
                rel_left = bbox[0][0]
                rel_top = bbox[0][1]
                rel_width = bbox[1][0] - bbox[0][0]
                rel_height = bbox[2][1] - bbox[0][1]
                results.append(
                    {
                        "text": text,
                        "left": int(x1 + rel_left),
                        "top": int(y1 + rel_top),
                        "width": int(rel_width),
                        "height": int(rel_height),
                        "conf": float(conf * 100),
                        "bbox": {
                            "left": int(x1 + rel_left),
                            "top": int(y1 + rel_top),
                            "width": int(rel_width),
                            "height": int(rel_height),
                        },
                    }
                )
        return results

    def get_text_with_position(self, image: np.ndarray) -> List[Dict]:
        data = pytesseract.image_to_data(
            image, config=self.config, output_type=pytesseract.Output.DICT
        )
        results = []
        for i in range(len(data["text"])):
            if int(data["conf"][i]) > 0 and data["text"][i].strip():
                results.append(
                    {
                        "text": data["text"][i],
                        "left": data["left"][i],
                        "top": data["top"][i],
                        "width": data["width"][i],
                        "height": data["height"][i],
                        "conf": data["conf"][i],
                        "bbox": {
                            "left": data["left"][i],
                            "top": data["top"][i],
                            "width": data["width"][i],
                            "height": data["height"][i],
                        },
                    }
                )
        return results

    def process_image(self, image: np.ndarray) -> List[Dict]:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        preprocessed_img = cv2.GaussianBlur(gray, (5, 5), 0)
        _, binary_img = cv2.threshold(preprocessed_img, 150, 255, cv2.THRESH_BINARY)

        text_regions = self.detect_text_regions(binary_img)
        easyocr_results = self.extract_text_from_regions(image, text_regions)

        if not easyocr_results:
            all_results = []
            for x1, y1, x2, y2 in text_regions:
                region = image[y1:y2, x1:x2]
                if region.size == 0:
                    continue
                preprocessed_versions = self.preprocess_image(region)
                best_results = []
                best_confidence = 0

                for name, prep_image in preprocessed_versions:
                    results = self.get_text_with_position(prep_image)
                    confidences = [
                        float(r["conf"]) for r in results if r["text"].strip()
                    ]
                    avg_confidence = statistics.mean(confidences) if confidences else 0
                    if avg_confidence > best_confidence:
                        best_confidence = avg_confidence
                        best_results = results

                for result in best_results:
                    result["left"] += x1
                    result["top"] += y1
                    result["bbox"]["left"] += x1
                    result["bbox"]["top"] += y1
                all_results.extend(best_results)
            return all_results

        return [r for r in easyocr_results if r["text"].strip()]

    def extract_text(self, file_path: str) -> List[Dict]:
        try:
            img = cv2.imread(file_path)
            if img is None:
                raise ValueError(f"Could not read image at {file_path}")

            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            preprocessed_img = cv2.GaussianBlur(gray, (5, 5), 0)
            _, binary_img = cv2.threshold(preprocessed_img, 150, 255, cv2.THRESH_BINARY)

            try:
                preprocessed_path = file_path.replace("raw", "preprocessed")
                os.makedirs(os.path.dirname(preprocessed_path), exist_ok=True)
                cv2.imwrite(preprocessed_path, binary_img)
            except Exception as e:
                print(f"Warning: Could not save preprocessed image: {str(e)}")

            return self.process_image(img)

        except Exception as e:
            print(f"Error processing image: {str(e)}")
            return []


ocr_processor = EnglishOCR()
extract_text = ocr_processor.extract_text

if __name__ == "__main__":
    import sys

    def calculate_performance_metrics(results, image_shape):
        if not results:
            print("\n⚠️ No text detected, so performance metrics are undefined.")
            return

        confidences = []
        word_count = 0
        char_count = 0
        total_text_area = 0

        for r in results:
            try:
                conf = float(r["conf"])
                confidences.append(conf)
            except (KeyError, ValueError):
                continue
            word_count += len(r["text"].split())
            char_count += len(r["text"])
            total_text_area += r["width"] * r["height"]

        avg_conf = statistics.mean(confidences) if confidences else 0
        h, w = image_shape[:2]
        total_image_area = w * h
        coverage_percent = (
            (total_text_area / total_image_area) * 100 if total_image_area else 0
        )

        print(f"\n📈 Performance Metrics:")
        print(f"🧠 Average OCR Confidence: {avg_conf:.2f}%")
        print(f"🔤 Total Words Detected: {word_count}")
        print(f"🔠 Total Characters Detected: {char_count}")
        print(f"🧱 Text Region Coverage: {coverage_percent:.2f}% of image area")
        print(f"📦 Total Text Boxes: {len(results)}")

    if len(sys.argv) > 1:
        image_path = sys.argv[1]
        results = extract_text(image_path)

        print(f"📄 Found {len(results)} text regions:")
        for result in results:
            print(f"📝 Text: {result['text']}")
            print(f"📍 Position: ({result['left']}, {result['top']})")
            print(f"✅ Confidence: {result['conf']}%")
            print("---")

        image = cv2.imread(image_path)
        if image is not None:
            calculate_performance_metrics(results, image.shape)
        else:
            print("⚠️ Could not load image for performance metrics.")
    else:
        print("⚠️ Please provide an image path as argument")

import re
import os
from datetime import datetime
from io import BytesIO
import base64
import gridfs
import pytesseract
from bson import ObjectId
from PIL import Image
from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash,
    Response,
    jsonify,
    send_file,
)
from flask_bcrypt import Bcrypt
from flask_jwt_extended import (
    JWTManager,
    create_access_token,
    jwt_required,
    get_jwt_identity,
)
from flask_cors import CORS
from pymongo import MongoClient

from modules.format_utils import format_text
from modules.english_ocr import EnglishOCR
from modules.devanagari_ocr import DevanagariOCR
from modules.hindi_ocr import HindiOCR  # Import the new Hindi OCR module

app = Flask(__name__)

CORS(app)
app.secret_key = os.urandom(24)
print("Flask app has started.")

# MongoDB Connection
client = MongoClient("mongodb://127.0.0.1:27017/")

db = client["digieasedb"]
users_collection = db["users"]
documents_collection = db["documents"]
preprocessed_documents_collection = db["preprocessed_documents"]
fs = gridfs.GridFS(db)
print("✅ MongoDB connected successfully.")

bcrypt = Bcrypt(app)
app.config["JWT_SECRET_KEY"] = "your_secret_key"  # Should be in environment variables
jwt = JWTManager(app)

# Upload directories - defined once
UPLOAD_FOLDER = "uploads/raw/"
RESULTS_FOLDER = "uploads/results/"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULTS_FOLDER, exist_ok=True)

# Updated language support to include Hindi
SUPPORTED_LANGUAGES = [
    {"code": "eng", "name": "English"},
    {"code": "devanagari", "name": "Marathi"},
    {"code": "hindi", "name": "Hindi"},  # Add Hindi as a supported language
]

# Initialize OCR processors
english_ocr = EnglishOCR()
devanagari_ocr = DevanagariOCR()
hindi_ocr = HindiOCR()  # Initialize the Hindi OCR processor


def fix_base64_padding(base64_str):
    missing_padding = len(base64_str) % 4
    if missing_padding:
        base64_str += "=" * (4 - missing_padding)
    return base64_str


def validate_password(password):
    if len(password) < 8:
        return "Password must be at least 8 characters long."
    if not re.search(r"[A-Z]", password):
        return "Password must contain at least one uppercase letter."
    if not re.search(r"[a-z]", password):
        return "Password must contain at least one lowercase letter."
    if not re.search(r"\d", password):
        return "Password must contain at least one digit."
    if not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        return "Password must contain at least one special character."
    return None


@app.route("/")
def home():
    if "user" in session:
        return redirect(url_for("dashboard"))
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]
        firstname = request.form["firstname"]

        # Validate password
        password_error = validate_password(password)
        if password_error:
            flash(password_error, "danger")
            return redirect(url_for("register"))

        # Check if user already exists
        existing_user = users_collection.find_one({"email": email})
        if existing_user:
            flash("User already exists!", "danger")
            return redirect(url_for("register"))

        try:
            # Hash the password
            hashed_password = bcrypt.generate_password_hash(password).decode("utf-8")

            # Insert the new user into the database
            users_collection.insert_one(
                {"email": email, "password": hashed_password, "firstname": firstname}
            )

            flash("Registration successful! Please login.", "success")
            return redirect(url_for("login"))

        except Exception as e:
            flash(f"Error registering user: {str(e)}", "danger")
            return redirect(url_for("register"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        user = users_collection.find_one({"email": email})

        if not user or not bcrypt.check_password_hash(user["password"], password):
            flash("Invalid credentials!", "danger")
            return redirect(url_for("login"))

        session["user"] = {
            "id": str(user["_id"]),
            "email": user["email"],
            "firstname": user["firstname"],
        }

        flash("Login successful!", "success")
        return redirect(url_for("dashboard"))

    return render_template("login.html")


from datetime import datetime


@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        flash("Please log in first!", "warning")
        return redirect(url_for("login"))

    user_id = session["user"]["id"]

    return render_template("dashboard.html", user=session["user"])


@app.route("/history")
def history():
    if "user" not in session:
        flash("Please log in first!", "warning")
        return redirect(url_for("login"))

    user_id = session["user"]["id"]

    # Fetch all digitized documents for the user
    all_digitized_documents = list(
        preprocessed_documents_collection.find({"user_id": user_id}).sort(
            "upload_date", -1
        )
    )

    # Format upload_date
    for doc in all_digitized_documents:
        if "upload_date" in doc:
            doc["formatted_upload_date"] = (
                doc["upload_date"].strftime("%B %d, %Y")
                if isinstance(doc["upload_date"], datetime)
                else "N/A"
            )

    return render_template("history.html", history=all_digitized_documents)


@app.route("/documents")
def documents():
    if "user" not in session:
        flash("Please log in first!", "warning")
        return redirect(url_for("login"))

    user_id = session["user"]["id"]

    # Fetch all digitized documents for the user
    all_documents = list(
        documents_collection.find({"user_id": user_id}).sort("upload_date", -1)
    )

    # Format upload_date for all documents
    for doc in all_documents:
        if "upload_date" in doc:
            doc["formatted_upload_date"] = (
                doc["upload_date"].strftime("%B %d, %Y")
                if isinstance(doc["upload_date"], datetime)
                else "N/A"
            )
    # Debugging: Print all documents to check if `preprocessed_results` exists
    print("----- DEBUG: Checking documents -----")
    for doc in all_documents:
        print("Document ID:", doc.get("_id"))
        print("Filename:", doc.get("filename"))
        print(
            "Preprocessed Results:", doc.get("preprocessed_results")
        )  # This should NOT be None or empty
        print("-------------------------------------")

    return render_template(
        "documents.html", user=session["user"], documents=all_documents
    )


@app.route("/logout")
def logout():
    session.pop("user", None)
    flash("Logged out successfully!", "info")
    return redirect(url_for("login"))


@app.route("/upload", methods=["GET", "POST"])
def upload_document():
    if "user" not in session:
        flash("Please log in first!", "warning")
        return redirect(url_for("login"))

    if request.method == "POST":
        file = request.files.get("file")
        language = request.form.get("language")

        if not file:
            flash("No file selected!", "danger")
            return redirect(url_for("upload"))

        if not language:
            flash("Please select a language!", "danger")
            return redirect(url_for("upload"))

        filename = file.filename
        file_id = fs.put(file, filename=filename)
        print(f"✅ Uploaded raw file to GridFS with ID: {file_id}")

        doc_id = documents_collection.insert_one(
            {
                "filename": filename,
                "file_id": file_id,
                "user_id": session["user"]["id"],
                "language": language,
                "upload_date": datetime.now(),
                "status": "uploaded",
            }
        ).inserted_id
        print(f"Document ID: {doc_id}")  # Debugging line

        return redirect(url_for("process_image", doc_id=str(doc_id)))

    return render_template("upload.html", supported_languages=SUPPORTED_LANGUAGES)


# Update the process_image route to handle Hindi OCR
@app.route("/process_image")
def process_image():
    if "user" not in session:
        flash("Please log in first!", "warning")
        return redirect(url_for("login"))

    print("🔥 process_image route called!")

    doc_id = request.args.get("doc_id")
    if not doc_id:
        flash("No document ID provided!")
        return redirect(url_for("upload_document"))

    try:
        document = documents_collection.find_one({"_id": ObjectId(doc_id)})
        print(f"📝 Retrieved document: {document}")  # Debug print

        if not document:
            print("❌ Document not found in MongoDB!")
            flash("Document not found!", "danger")
            return redirect(url_for("upload_document"))

        file = fs.get(document["file_id"])
        filename = document["filename"]
        file_path = os.path.join(UPLOAD_FOLDER, filename)

        with open(file_path, "wb") as f:
            f.write(file.read())

        print(f"📂 File saved locally: {file_path}")  # Debug print

        # Select OCR processor based on language
        if document["language"] == "eng":
            processor = english_ocr
        elif document["language"] == "hindi":
            processor = hindi_ocr  # Use Hindi OCR processor
        else:
            processor = devanagari_ocr

        print(f"🔍 Selected OCR processor: {processor}")  # Debug print

        extracted_data = processor.extract_text(file_path)
        print(f"📜 Raw Extracted Data: {extracted_data}")  # Debug print

        png_output = format_text(extracted_data, file_path, output_format="png")
        extracted_text = " ".join(
            [item["text"] for item in extracted_data if item["text"].strip()]
        )

        print(f"📝 Final Extracted Text: {extracted_text}")  # Debug print

        # Calculate performance metrics
        metrics = {
            "avg_confidence": 0,
            "coverage_percent": 0,
            "text_boxes": 0,
            "word_count": 0,
            "char_count": 0,
        }

        import statistics
        import cv2
        import numpy as np

        if extracted_data:
            # Calculate metrics similar to calculate_performance_metrics in OCR processor
            confidences = []
            word_count = 0
            char_count = 0
            total_text_area = 0

            for item in extracted_data:
                try:
                    conf = float(item["conf"])
                    confidences.append(conf)
                except (KeyError, ValueError, TypeError):
                    continue

                word_count += len(item["text"].split())
                char_count += len(item["text"])

                # Calculate text area if bbox info is available
                if "bbox" in item and all(
                    k in item["bbox"] for k in ["width", "height"]
                ):
                    total_text_area += item["bbox"]["width"] * item["bbox"]["height"]
                elif all(k in item for k in ["width", "height"]):
                    total_text_area += item["width"] * item["height"]

            metrics["avg_confidence"] = (
                statistics.mean(confidences) if confidences else 0
            )

            # Get image dimensions to calculate coverage percentage
            img = cv2.imread(file_path)
            if img is not None:
                h, w = img.shape[:2]
                total_image_area = w * h
                metrics["coverage_percent"] = (
                    (total_text_area / total_image_area) * 100
                    if total_image_area
                    else 0
                )

            metrics["text_boxes"] = len(extracted_data)
            metrics["word_count"] = word_count
            metrics["char_count"] = char_count

        # Save results
        text_file_id = fs.put(
            extracted_text.encode("utf-8"), filename=f"extracted_{filename}.txt"
        )
        print(f"💾 Text file stored with ID: {text_file_id}")  # Debug print

        png_file_id = None
        if png_output:
            if isinstance(png_output, str):
                png_output = png_output.encode("utf-8")
            png_file_id = fs.put(png_output, filename=f"digitized_{filename}.png")
            print(f"🖼 PNG file stored with ID: {png_file_id}")  # Debug print

        if os.path.exists(file_path):
            os.remove(file_path)
            print(f"🗑 Deleted local file: {file_path}")  # Debug print

        # Store results with metrics
        insert_result = preprocessed_documents_collection.insert_one(
            {
                "file_id": document["file_id"],
                "user_id": session["user"]["id"],
                "filename": filename,
                "extracted_text": extracted_text,
                "text_file_id": (text_file_id),
                "png_file_id": (png_file_id) if png_file_id else None,
                "language": document["language"],
                "upload_date": datetime.now(),
                "ocr_metrics": metrics,  # Store metrics in the database
            }
        )

        print(
            f"✅ Preprocessed Document Inserted with ID: {insert_result.inserted_id}"
        )  # Debug print

        return render_template(
            "result.html",
            extracted_text=extracted_text,
            png_file_id=str(png_file_id) if png_file_id else None,
            language=document["language"],
            metrics=metrics,  # Pass metrics to the template
        )

    except Exception as e:
        print(f"❌ Error processing image: {str(e)}")  # Debug print
        flash(f"Error processing image: {str(e)}", "danger")
        return redirect(url_for("upload_document"))


@app.route("/get_png/<file_id>")
def get_png(file_id):
    try:
        if not file_id:
            return "❌ File ID is missing", 400

        png_file = fs.get(ObjectId(file_id))  # Fetch from GridFS
        return send_file(BytesIO(png_file.read()), mimetype="image/png")

    except gridfs.errors.NoFile:
        return "❌ File not found", 404

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/download_digitized_document/<doc_id>")
def download_digitized_document(doc_id):
    try:
        print(f"⬇️ Attempting to download document with ID: {doc_id}")

        # Get the file_type parameter (text or image)
        file_type = request.args.get("file_type", "text")

        # Fetch the digitized document from preprocessed_results_collection
        document = preprocessed_documents_collection.find_one({"_id": ObjectId(doc_id)})
        print(f"📄 Found document: {document}")

        if not document:
            print("❌ Document not found in preprocessed_documents_collection")
            flash("Digitized document not found!", "danger")
            return redirect(url_for("dashboard"))

        # If file_type is "image" and png_file_id exists, prioritize downloading the image
        if file_type == "image" and document.get("png_file_id"):
            print(
                f"🖼️ PNG file ID: {document['png_file_id']}, Type: {type(document['png_file_id'])}"
            )
            file = fs.get(document["png_file_id"])
            print("✅ Successfully retrieved PNG file from GridFS")
            download_filename = f"digitized_{document['filename'].split('.')[0]}.png"
            mimetype = "image/png"
        # Otherwise, if file_type is "text" and text_file_id exists, download the text file
        elif file_type == "text" and document.get("text_file_id"):
            print(
                f"📝 Text file ID: {document['text_file_id']}, Type: {type(document['text_file_id'])}"
            )
            file = fs.get(document["text_file_id"])
            print("✅ Successfully retrieved text file from GridFS")
            download_filename = f"digitized_{document['filename'].split('.')[0]}.txt"
            mimetype = "text/plain"
        # If the requested file type doesn't exist, try the other type
        elif document.get("text_file_id"):
            print(
                f"📝 Text file ID: {document['text_file_id']}, Type: {type(document['text_file_id'])}"
            )
            file = fs.get(document["text_file_id"])
            print("✅ Successfully retrieved text file from GridFS")
            download_filename = f"digitized_{document['filename'].split('.')[0]}.txt"
            mimetype = "text/plain"
        elif document.get("png_file_id"):
            print(
                f"🖼️ PNG file ID: {document['png_file_id']}, Type: {type(document['png_file_id'])}"
            )
            file = fs.get(document["png_file_id"])
            print("✅ Successfully retrieved PNG file from GridFS")
            download_filename = f"digitized_{document['filename'].split('.')[0]}.png"
            mimetype = "image/png"
        else:
            print("❌ No file ID found in document")
            flash("No digitized file available!", "danger")
            return redirect(url_for("dashboard"))

        # Send the file to the client for download
        print(f"📤 Sending file: {download_filename}, MIME: {mimetype}")
        return send_file(
            BytesIO(file.read()),
            mimetype=mimetype,
            as_attachment=True,
            download_name=download_filename,
        )

    except gridfs.errors.NoFile as nf:
        print(f"❌ File not found in GridFS: {str(nf)}")
        flash("Digitized file not found in storage!", "danger")
        return redirect(url_for("dashboard"))

    except Exception as e:
        print(f"❌ Error downloading document: {str(e)}")
        flash(f"Error downloading digitized document: {str(e)}", "danger")
        return redirect(url_for("dashboard"))


@app.route("/document/<doc_id>/delete", methods=["POST", "DELETE"])
def delete_document(doc_id):
    # Delete the document from the preprocessed_documents_collection
    preprocessed_documents_collection.delete_one({"_id": ObjectId(doc_id)})

    # Redirect back to the history page
    return redirect(url_for("history"))


@app.route("/about")
def about():
    return render_template("about.html")


if __name__ == "__main__":
    app.run(debug=True)

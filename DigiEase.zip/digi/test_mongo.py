from pymongo import MongoClient

client = MongoClient("mongodb://127.0.0.1:27017/")
db = client["digieasedb"]
documents_collection = db["documents"]

test_doc = {"test": "MongoDB Connection Working"}
documents_collection.insert_one(test_doc)

print(
    "Inserted:", documents_collection.find_one({"test": "MongoDB Connection Working"})
)
